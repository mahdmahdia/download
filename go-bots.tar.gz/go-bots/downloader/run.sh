#!/usr/bin/env bash
BINARY="go run --race main.go"
$BINARY
#CONFIG="./config.json"
#$BINARY --config $CONFIG
