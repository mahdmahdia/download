cd bin
gox ..
#sed -i "s/TELEGRAM_KEY=.*/TELEGRAM_KEY=YOURKEY/" secrets.env
